#! /bin/bash
cryptroot=$1

function do_suspend() {
	pm-suspend
      }

function do_lockunlock() {
   sync
   cryptsetup luksSuspend $cryptroot
   sync

   echo "Attempting to suspend"
   do_suspend &
   sleep 1
   echo "- Attempting to unlock..."

   cryptsetup luksResume $cryptroot
}

sleep 2
do_lockunlock
