#!/bin/bash
chrootdir="/boot/suspend"
cryptroot=$(lsblk -lno 'NAME,MOUNTPOINT' | awk '$2 ~ "/$" {print $1}')

if [ -z ${cryptroot+x} ] ; then
 echo "no cryptroot found"
 exit 1
else
  echo "cryptroot set to $cryptroot"
fi

for dir in dev proc sys; do
  mount --rbind /$dir $chrootdir/$dir
done

openvt -c 8 -swf chroot $chrootdir /chrootsuspend.sh "$cryptroot"

for dir in dev proc sys; do
   umount -l $chrootdir/$dir
done

